import Vue from 'vue'
import Vuex from 'vuex'
import router  from './routes'
Vue.use(Vuex);


export default new Vuex.Store({
    state: {
        userName: null,
        token: null,
        alert: false,
        selectedData: [],
    },
    mutations: {
        logout: state => {
            state.userName = null;
            localStorage.removeItem('token');
            router.push('/');
        },
        login: (state, payload) => {

            if(payload.user === 'admin' && payload.password === '12345') {
                state.userName = 'Ahosan';
                state.token = 'Basic c2Fyb2FyOjEyMzQ=';
                state.alert = false;
                localStorage.setItem('token', state.token);
                router.push('/main');
            }else
                state.alert = true;
        },
        updateSession: (state, payload) => {
            state.userName = payload.user;
            state.token = payload.token;
        }
    },
    actions: {
        logout: ({commit}) => {
            commit('logout');
        },
        login: ({commit}, payload) => {
            commit('login', payload);
        },
        tryToLogin ({commit}) {
            const  token = localStorage.getItem('token');
            if(!token) {
                router.push('login');
                return
            }
            commit('updateSession', {user: 'Ahosan', token: token});
        }
    },
    getters: {
        isAuthenticated(state) {
            return state.token !== null;
        }
    }
});
