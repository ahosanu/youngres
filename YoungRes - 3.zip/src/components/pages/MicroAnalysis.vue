<template>
    <div class="container">

        <div class="content">
            <p>You have selected:</p>
            <br/>
            <div class="row">
                <div class="col-3">
                    <select class="custom-select">
                        <option selected>Videogame 1</option>
                        <option>Videogame 2</option>
                        <option>Videogame 3</option>
                        <option>Videogame 4</option>
                        <option>Videogame 5</option>
                    </select>
                </div>
                <div class="col-3">
                    <select class="custom-select" style="margin-left: 10px;">
                        <option>Chapter 1</option>
                        <option>Chapter 2</option>
                        <option>Chapter 3</option>
                        <option>Chapter 4</option>
                        <option selected>Chapter 5</option>
                    </select>
                </div>
                <div class="col-3">
                    <select class="custom-select" v-model="choice" style="margin-left: 10px;">
                        <option selected value="choice">Multiple-choice</option>
                        <option value="temp">Temporal</option>
                        <option value="xpe">A specific</option>
                    </select>
                </div>
                <div class="col-3">
                    <button class="btn btn-outline-primary" @click="filter()">Filter</button>
                </div>
            </div>
            <div class="row">
                <div class="offset-2 col-7">
                    <v-chart :options="chartData"/>
                </div>
                <div class="col-3">
                    <ul class="eventlist">
                        <li v-for="item in distinct_event" :key="item" @click="gotoEvent(item)"> {{item}}</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row" style="padding: 20px 0">
            <div class="col-4">
                <button class="btn btn-outline-primary" @click="back">Back</button>
            </div>
            <div class="col-4 text-center">
                <button class="btn btn-outline-primary" @click="home">Home</button>
            </div>
            <div class="col-4 text-right">

                <button class="btn btn-outline-primary" @click="exportOpt">Export</button>
            </div>
        </div>
    </div>
</template>

<script>
    import ECharts from 'vue-echarts'
    import 'echarts/lib/chart/bar'
    import 'echarts/lib/component/tooltip'
    import 'echarts-gl'
    //import filterModel from "@/components/filterModel";

    export default {
        components: {
            'v-chart': ECharts
        },
        data: function(){
            return {
                chartData: null,
                Answers: [10, 20 , 50, 15, 50, 80, 25, 30, 80, 95],
                choice: 'choice',
                decisions: [
                    {
                        "choice": "cat",
                        "eventCode": "e1",
                        "eventDescription": "student is asked for its favorite pet...",
                        "eventType": "choice"
                    },
                    {
                        "choice": "dog",
                        "eventCode": "e1",
                        "eventDescription": "student is asked for its favorite pet...",
                        "eventType": "choice"
                    },
                    {
                        "choice": "cat",
                        "eventCode": "e1",
                        "eventDescription": "student is asked for its favorite pet...",
                        "eventType": "choice"
                    },
                    {
                        "choice": "catfish",
                        "eventCode": "e2",
                        "eventDescription": "student is asked for its favorite fish...",
                        "eventType": "choice"
                    },
                    {
                        "choice": "salmon",
                        "eventCode": "e2",
                        "eventDescription": "student is asked for its favorite fish...",
                        "eventType": "choice"
                    }
                ],
                filter_decisions:'',
                distinct: [],
                distinct_event: [],
                unique: [],
                unique_event:[],
                unique_decision:[],
                unique_decision_final:[],
                type: this.$route.params.type,
                game: this.$route.params.game,
                chapter: this.$route.params.chapter,
                chartDATA: [],


            }
        },
        mounted(){
            this.fil(this.choice);

           for(var i=0; i < this.unique_decision_final.length; i++ )
               this.chartDATA[i] = [];

            for(var p =0; p < this.unique_decision_final.length; p++){
                var list = this.unique_decision_final[p].choice;
                for(var j=0; j < list.length; j++) {
                    this.chartDATA[j].push(list[j][1]);
                }
            }
            this.barChartLoad();
        }
        ,
        methods: {
            exportOpt(){

            },
            home(){
                this.$router.push('/main');
            },
            filter(){
                this.$modal.show('filter');
            }
            ,
            back(){
                this.$router.back();
            },
            fil(type){
                this.filter_decisions='';
                this.distinct= [];
                this.distinct_event= [];
                this.unique= [];
                this.unique_event=[];
                this.unique_decision=[];
                this.unique_decision_final=[];

                // Filter decsion based on Type (timed or choice)
                this.filter_decisions =  this.decisions.filter(function(data) {return data.eventType == type; });

                // Number of distinct choices:
                for( let i = 0; i < this.filter_decisions.length; i++ ){
                    if( !this.unique[this.filter_decisions[i].choice]){
                        this.distinct.push(this.filter_decisions[i].choice);
                        this.unique[this.filter_decisions[i].choice] = 1;
                    }
                }

                // Number of distinct Events:
                this.unique= [];
                for( let i = 0; i < this.filter_decisions.length; i++ ){
                    if( !this.unique[this.filter_decisions[i].eventCode]){
                        this.distinct_event.push(this.filter_decisions[i].eventCode);
                        this.unique[this.filter_decisions[i].eventCode] = 1;
                    }
                }


                // List  of choices based on  Events:
                for( let i = 0; i < this.distinct_event.length; i++ ){
                    let event=this.distinct_event[i]
                    this.unique_event.push(this.filter_decisions.filter(function(data) {return data.eventCode == event;}));
                }

                // Number of choice taken by same student

                for( let i = 0; i < this.unique_event.length; i++ ){
                    let event=this.unique_event[i]
                    for( let i = 0; i < this.distinct.length; i++ ){
                        let schoice=this.distinct[i]
                        let sevent=event.filter(function(data) {return data.choice == schoice;});
                        if (sevent.length != 0) {this.unique_decision.push({'event': sevent[0].eventCode,'description':sevent[0].eventDescription,"choice": schoice,"student": sevent.length});}
                    }
                }

                // Final process data
                for( let i = 0; i < this.distinct_event.length; i++ ){
                    let event=this.distinct_event[i]
                    let final=this.unique_decision.filter(function(data) {return data.event == event;});
                    let choice=[]
                    let x=i;
                    for (let i =0; i < final.length; i++) {
                        choice.push([final[i].choice, ((100/this.unique_event[x].length)*final[i].student).toFixed(2)]);
                    }
                    this.unique_decision_final.push({ "eventCode": final[i].event, "choice": choice,"eventDescription": final[i].description,"eventType": type } );
                }
            },
            barChartLoad(){


                var emphasisStyle = {
                    itemStyle: {
                        barBorderWidth: 1,
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowOffsetY: 0,
                        shadowColor: 'rgba(0,0,0,0.5)'
                    }
                };
                this.chartData = {
                    backgroundColor: '#fff',



                    tooltip: {
                        formatter: function (params) {
                            //console.log(params);
                            return 'This Value is : ' + params.value;
                        }
                    },
                    xAxis: {
                        data: this.distinct_event,
                        axisLine: {onZero: true},
                        splitLine: {show: true},
                        splitArea: {show: false}
                    },
                    yAxis: {
                        max: 100,
                        splitArea: {show: false}
                    },
                    series: [
                        {
                            name: 'bar',
                            type: 'bar',
                            stack: 'one',
                            emphasis: emphasisStyle,
                            data: this.chartDATA[0]
                        },
                        {
                            name: 'bar2',
                            type: 'bar',
                            stack: 'one',
                            emphasis: emphasisStyle,
                            data: this.chartDATA[1]
                        },
                        {
                            name: 'bar3',
                            type: 'bar',
                            stack: 'one',
                            emphasis: emphasisStyle,
                            data: this.chartDATA[2]
                        }
                    ]
                };
            },
            gotoEvent(value){


                this.$router.push(this.$route.path + '/' + value + '/EventView');
            }
        }
    }
</script>

<style scoped lang="scss">
    .content{
        margin: 50px 0;
    .custom-control{
        margin-top: 16px;
    }
    }
    .eventlist{
        list-style: none;
        padding: 0;
        margin: 50px 0;
        li {
            padding: 13px 20px;
            background: #325973;
            color: white;
            border: 1px solid white;
            cursor: pointer;
        }
        li:hover{
            background: #848484;
        }
    }
</style>
