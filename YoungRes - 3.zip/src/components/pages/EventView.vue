<template>
    <div class="container">
        <div class="loading" v-if="loading">
            <div class="centerScreen">
                <div class="spinner-grow text-dark" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
        </div>
        <div class="content">
            <p>You have selected:</p>
            <br/>
            <div class="row">
                <div class="col-3">
                    <select class="custom-select" style="margin-left: 10px;" @change="changeChapter($event)">
                        <option v-for="(item, index) in chapters" :key="index" :value="item">{{item}} </option>
                    </select>
                </div>
                <div class="col-3">
                    <select class="custom-select" style="margin-left: 10px;" @change="changeEvent($event)">
                        <option v-for="(item, index) in events" :key="index" :value="item">{{item}} </option>
                    </select>
                </div>
                <div class="col-3">
                    <button class="btn btn-outline-primary">Filter</button>
                </div>
            </div>
            <br/>
            <div class="row">
                <div class="col-7">
                    <v-chart :options="chartData"/>
                    <!--<img src="@/assets/image2.png" style="width: 100%;" alt="">-->
                </div>
                <div class="col-5">
                    <strong>Event 4:</strong>
                    <p>{{description}}</p>
                    <strong>Highlights:</strong>
                   <p v-for="(item, index) in this.highlights" :key="index">{{item}}</p>
                    There are three possible answers:
                    <br/>
                    - Answer 1: “I forgive you”.<br/>
                    Selected by: 52%<br/>
                    - Answer 2: “I hate you”.<br/>
                    Selected by: 20 %<br/>
                    - Answer 3: “Leave me alone, please”.<br/>
                    Selected by: 28 %<br/>

                </div>
            </div>
        </div>
        <div class="row" style="padding: 20px 0">
            <div class="col-4">
                <button class="btn btn-outline-primary" @click="back">Back</button>
            </div>
            <div class="col-4 text-center">
                <button class="btn btn-outline-primary" @click="home">Home</button>
            </div>
            <div class="col-4 text-right">

                <button class="btn btn-outline-primary" @click="exportOpt">Export</button>
            </div>
        </div>
    </div>
</template>

<script>
    //import axios from "axios";
    import ECharts from 'vue-echarts'
    import 'echarts/lib/chart/bar'
    import 'echarts/lib/component/tooltip'
    import 'echarts-gl'

    export default {
        components: {
            'v-chart': ECharts
        },
        data: function() {

            return {
                SelectedEvent: "event3.5",
                result: null,
                description: null,
                highlights: [],
                Answers: [],
                chartData: null,
                loading: true,
                selectedChapter: null,
                selectedData: null,
                chapters: [],
                events: ['e1', 'e2']
            };
        },
        mounted(){
            let data = {
                "chapters": [
                    "C1",
                    "C2"
                ],
                "countries": [
                    "Spain",
                    "Finland"
                ],
                "gameCode": "G1",
                "gameDescription": "Game were LGTBI content is discussed",
                "gameVersion": "v1",
                "numberPlayers": "60"
            };
            this.chapters = data.chapters;

            this.selectedChapter = this.$route.params.chapter;
           this.loadData();

        },
        methods: {
            exportOpt(){

            },
            changeChapter(event){
                this.selectedChapter = event.target.value;
                this.loadData();
            },
            changeEvent(event){
                this.SelectedEvent = event.target.value;
                this.loadData();
            }
            ,
            loadData(){
                this.loading = true;
                /*axios
                    .get('http://torresquevedo.eui.upm.es:8883/data/descriptions/event?gameCode='+this.SelectedData.selectedGame+'&gameVersion='+this.SelectedData.selectedGameVersion+'&chapterCode='+this.SelectedData.selectedChapter+'&eventCode='+this.SelectedEvent, { headers: { 'Accept': 'application/json', 'Authorization': 'Basic c2Fyb2FyOjEyMzQ=' } })
                    .then(response => {
                        this.result = JSON.parse(response.request.response);
                        console.log( this.result);
                        this.highlights = this.result.highlights;
                        this.Answers = this.result.possibleChoices;
                        this.description = this.result.eventDescription;
                        this.barChartLoad();
                        this.loading = false;
                    });*/


                this.result = {
                    "eventCode": "e3",
                    "eventDescription": "Seconds waiting for your friend",
                    "eventType": "timed",
                    "highlights": [ "H1 - Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,." ],
                    "possibleChoices": [
                        "10",
                        "90"
                    ]
                };

                this.highlights = this.result.highlights;
                this.Answers = this.result.possibleChoices;
                this.description = this.result.eventDescription;
                this.barChartLoad();
                this.loading = false;

            },
            home(){

                this.$router.push('/main');
            },

            back(){
                this.$router.back();
            },
            barChartLoad(){
                var dataAxis = [];
                var data = this.Answers;
                var yMax = 100;
                var dataShadow = [];




                for (var i = 0; i < data.length; i++) {
                    dataAxis.push('Answ '+ (i+1));
                    dataShadow.push(yMax);
                }
                this.chartData = {
                    xAxis: {
                        data: dataAxis,

                        axisTick: {
                            show: false
                        },
                        axisLine: {
                            show: false
                        },
                        z: 10
                    },
                    yAxis: {
                        type : 'value',
                        axisLine: {
                            show: false
                        },
                        axisTick: {
                            show: false
                        },
                        axisLabel: {
                            textStyle: {
                                color: '#999'
                            },
                            formatter: '{value}%'
                        }
                    },
                    dataZoom: [
                        {
                            type: 'inside'
                        }
                    ],
                    series: [
                        { // For shadow
                            type: 'bar',
                            itemStyle: {
                                color: 'rgba(0,0,0,0.05)'
                            },
                            barGap: '-100%',
                            barCategoryGap: '40%',
                            data: dataShadow,
                            animation: false
                        },
                        {
                            type: 'bar',
                            data: data
                        }
                    ]
                }
            }
        }
    }
</script>

<style scoped lang="scss">
    .loading {
        position: fixed;
        top: 0;
        left: 0;
        background: #0000003d;
        height: 100%;
        width: 100%;
        z-index: 99999;
        .centerScreen {
            position: fixed;
            width: 100%;
            transform: translate(50%, 50%);
            height: 100%;
            margin-left: -2.5rem;
            margin-top: -2.5rem;

            .spinner-grow {
                width: 5rem;
                height: 5rem;
            }

            .text-dark {
                color: #e35219 !important;
            }
        }
    }
</style>
